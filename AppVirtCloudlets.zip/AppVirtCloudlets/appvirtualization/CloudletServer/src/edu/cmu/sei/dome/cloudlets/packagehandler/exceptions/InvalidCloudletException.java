package edu.cmu.sei.dome.cloudlets.packagehandler.exceptions;

public class InvalidCloudletException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
