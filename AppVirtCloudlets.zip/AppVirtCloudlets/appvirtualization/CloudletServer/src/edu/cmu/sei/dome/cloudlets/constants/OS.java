package edu.cmu.sei.dome.cloudlets.constants;

public enum OS {
	windows, linux
}
