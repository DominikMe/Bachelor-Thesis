package edu.cmu.sei.dome.cloudlets.packagehandler.exceptions;

public class UnsupportedFileTypeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
