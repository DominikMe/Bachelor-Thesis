package edu.cmu.sei.dome.cloudlets.packagehandler.exceptions;

public class PackageNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

}
