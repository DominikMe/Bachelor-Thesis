all app virtualization code should go into this directory. 
